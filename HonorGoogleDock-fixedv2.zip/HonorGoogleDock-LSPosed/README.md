# HonorGoogleDock-LSPosed

Experimental LSPosed module for Honor Launcher 16.0.20.221. It adds a Google-style search bar overlay near the bottom of the launcher, attempts to move a view identified as Hotseat/Dock upward to make room, and hides the bar when the visible page-order label is detected.

## Build
Upload the contents of this folder to a GitHub repository root and run the included GitHub Actions workflow. The APK is produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Install
1. Build and install the new APK (uninstalling the old module APK first is recommended if Android refuses to update it).
2. In LSPosed, enable the module and scope it to the Honor Launcher package `com.hihonor.android.launcher` (verify the actual package name on your device).
3. Force-stop the launcher or reboot.

## Important limitations
- This remains a best-effort overlay, not a native insertion into Honor Launcher's Hotseat/Dock. It tries to shift views whose class names contain `Hotseat` or `Dock` upward by 66dp, but Honor may use different class names; if so, icons may still overlap. A native layout integration would be more reliable.
- The edit-mode auto-hide now checks only visible page-order labels, avoiding hidden widget labels. If Honor's edit UI uses different text, auto-hide may not trigger.
- The module has not been built by GitHub Actions or tested on a device in this environment. Please test and send the LSPosed log if it still overlays controls.
